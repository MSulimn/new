import logging

from app import api_app
from app.app_config import HOST, LOG_FILE



if __name__ == "__main__":
    logging.basicConfig(filename=LOG_FILE, level=logging.INFO)
    logfile = logging.getLogger('file')
    logconsole = logging.getLogger('console')

    api_app.run(host=HOST, debug=True, threaded=True)
