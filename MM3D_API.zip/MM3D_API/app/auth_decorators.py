from logging import ERROR, INFO
from app.constants import (
    STATUS_FAILED,
    CODE_GOOGLE_AUTH_NO_TOKEN_PROVIDED,
    CODE_GOOGLE_AUTH_TOKEN_EXPIRED,
    CODE_GOOGLE_AUTH_TOKEN_WRONG_ISSUER,
    CODE_GOOGLE_AUTH_UNCAUGHT_EXCEPTION,
    CODE_KEY_EXCHANGE_NO_SIGNATURE_PROVIDED,
    CODE_KEY_EXCHANGE_NO_SIGNED_DATA_PROVIDED,
    CODE_KEY_EXCHANGE_INVALID_SIGNATURE,
    CODE_KEY_EXCHANGE_UNCAUGHT_EXCEPTION,
)

from functools import wraps
from google.oauth2 import id_token
from flask import jsonify
from flask import request as flask_request
from cryptography.exceptions import InvalidSignature

from app import request, ke
from app.app_config import PROJECT_ID, PROJECT_ISS
from app.logger import log


def google_token_required(function):
    """Decorator function (wrapper) for requiring and validating a Firebase token

    Args:
        function (callable): Function that requires the user to be authenticated
        with Google Firebase Auth Service (logged into mobile app) to be called

    Raises:
        ValueError: In case of failed token verification (wrong issuer or token expiration)

    Returns:
        JSONObject or decoration: In case of error an appropriate message is returned,
        otherwise decorated function is returned
    """

    @wraps(function)
    def decorated(*args, **kwargs):
        token = flask_request.headers.get("token")

        if not token:
            log(ERROR, "GoogleAuth:NoTokenProvided")
            return jsonify({"status": STATUS_FAILED, "code": CODE_GOOGLE_AUTH_NO_TOKEN_PROVIDED}), 401

        else:
            try:
                idinfo = id_token.verify_firebase_token(token, request, PROJECT_ID)
                if idinfo["iss"] != PROJECT_ISS:
                    raise ValueError("Wrong issuer.")

            except ValueError as exception:
                if "expired" in str(exception):
                    log(ERROR, "GoogleAuth:TokenExpired:" + idinfo["sub"], exception, True)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_GOOGLE_AUTH_TOKEN_EXPIRED}), 403

                else:
                    log(ERROR, "GoogleAuth:WrongTokenIssuer:" + idinfo["sub"], exception, True)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_GOOGLE_AUTH_TOKEN_WRONG_ISSUER}), 403

            except Exception as exception:
                log(ERROR, "GoogleAuth:UncaughtException:" + idinfo["sub"], exception, True)
                return jsonify({"status": STATUS_FAILED, "code": CODE_GOOGLE_AUTH_UNCAUGHT_EXCEPTION}), 500

            else:
                log(INFO, "GoogleAuth:RequestAuthenticated:" + idinfo["sub"])
                kwargs["uid"] = idinfo["sub"]

            return function(*args, **kwargs)

    return decorated


def ke_signature_required(function):
    """Decorator function (wrapper) for requiring and validating
    signature coming from machine based on Ed25519 key exchange.

    Args:
        function (callable): Function that requires the user to be authenticated
        with Ed25519 key (established between machine and API) to be called

    Returns:
        JSONObject or decoration: In case of error an appropriate message is returned,
        otherwise decorated function is returned
    """

    @wraps(function)
    def decorated(*args, **kwargs):
        signature = flask_request.headers.get("signature")
        signed_data = flask_request.headers.get("signed_data")

        if not signature:
            log(ERROR, "KeyExchange:NoSignatureProvided")
            return jsonify({"status": STATUS_FAILED, "code": CODE_KEY_EXCHANGE_NO_SIGNATURE_PROVIDED}), 401

        elif not signed_data:
            log(ERROR, "KeyExchange:NoSignedDataProvided")
            return jsonify({"status": STATUS_FAILED, "code": CODE_KEY_EXCHANGE_NO_SIGNED_DATA_PROVIDED}), 500

        else:
            try:
                ke.verify(signed_data, signature)

            except InvalidSignature:
                log(ERROR, "KeyExchange:InvalidSignature")
                return jsonify({"status": STATUS_FAILED, "code": CODE_KEY_EXCHANGE_INVALID_SIGNATURE}), 500

            except Exception:
                log(ERROR, "KeyExchange:UncaughtException")
                return jsonify({"status": STATUS_FAILED, "code": CODE_KEY_EXCHANGE_UNCAUGHT_EXCEPTION}), 500

            else:
                log(INFO, "KeyExchange:AuthenticationSuccessful")

            return function(*args, **kwargs)

    return decorated
