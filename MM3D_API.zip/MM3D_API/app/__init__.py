import yaml
import logging
import logging.config
import requests
import cachecontrol

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from google.auth.transport import requests as google_requests

from app.crypto import Crypto_RSA, KeyExchange, ArduinoChaCha
from app.app_config import LOG_CONFIG_FILE


api_app = Flask(__name__)
api_app.config.from_object("app.app_config.Config")
logging.config.dictConfig(yaml.safe_load(open(LOG_CONFIG_FILE)))

session = requests.session()
cached_session = cachecontrol.CacheControl(session)
request = google_requests.Request(session=cached_session)

db = SQLAlchemy()
ma = Marshmallow()
ke = KeyExchange()
rsa = Crypto_RSA()
chacha = ArduinoChaCha()

db.init_app(api_app)
ma.init_app(api_app)

import app.mobile_app_routes
import app.machine_app_routes
