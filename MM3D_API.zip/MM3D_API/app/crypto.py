import os
import base64
import string
import secrets

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives.asymmetric.padding import MGF1, OAEP
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

from django.utils.encoding import force_bytes, force_str
from logging import log, CRITICAL

from app.app_config import (
    KEY_SIZE,
    KEY_ENCRYPTION_PW_CONSUMABLE,
    KEY_ENCRYPTION_PW_OPERATOR,
    PRIVATE_KEY_FILE_CONSUMABLE,
    PUBLIC_KEY_FILE_CONSUMABLE,
    PRIVATE_KEY_FILE_OPERATOR,
    PUBLIC_KEY_FILE_OPERATOR,
)


class Crypto_RSA:
    """RSA-based encryption for encrypting and decoding data used in QR codes.
    """

    def __init__(self):
        """Init with default backend.
        """
        self.backend = default_backend()
        self.private_key_consumable = None
        self.public_key_consumable = None
        self.private_key_operator = None
        self.public_key_operator = None

    def generate_new_key_pair(self, size=None):
        """Generates new key pair, saves them to corresponding files and loads
        these keys for use. It's not used here in API but the method is here
        just to have it defined somewhere.
        """
        if size is None:
            key_size = KEY_SIZE
        else:
            key_size = size

        # Generate key pairs:
        self.private_key_consumable = rsa.generate_private_key(
            public_exponent=65537, key_size=key_size, backend=self.backend
        )
        self.public_key_consumable = self.private_key_consumable.public_key()
        self.private_key_operator = rsa.generate_private_key(
            public_exponent=65537, key_size=key_size, backend=self.backend
        )
        self.public_key_operator = self.private_key_operator.public_key()

        # Serialize keys into pem format
        pem_private_consumable = self.private_key_consumable.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.BestAvailableEncryption(KEY_ENCRYPTION_PW_CONSUMABLE),
        )
        pem_public_consumable = self.public_key_consumable.public_bytes(
            encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        pem_private_operator = self.private_key_consumable.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.BestAvailableEncryption(KEY_ENCRYPTION_PW_OPERATOR),
        )
        pem_public_operator = self.public_key_operator.public_bytes(
            encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

        # Save pem-serialized keys to files
        with open(PRIVATE_KEY_FILE_CONSUMABLE, "wb") as file:
            file.write(pem_private_consumable)
        with open(PUBLIC_KEY_FILE_CONSUMABLE, "wb") as file:
            file.write(pem_public_consumable)
        with open(PRIVATE_KEY_FILE_OPERATOR, "wb") as file:
            file.write(pem_private_operator)
        with open(PUBLIC_KEY_FILE_OPERATOR, "wb") as file:
            file.write(pem_public_operator)

    def _load_private_key(self, mode):
        """Loads private key from file.
        """
        if mode == "consumable":
            key_file = PRIVATE_KEY_FILE_CONSUMABLE
            password = KEY_ENCRYPTION_PW_CONSUMABLE
        else:
            key_file = PRIVATE_KEY_FILE_OPERATOR
            password = KEY_ENCRYPTION_PW_OPERATOR

        try:
            with open(key_file, "rb") as private_key_file:
                private_key = serialization.load_pem_private_key(
                    private_key_file.read(), password=password, backend=self.backend
                )
        # ValueErrors are risen in case of any other exceptions in order to be caught as plain decryption errors.
        except FileNotFoundError as exception:
            log(CRITICAL, "Private key file not found.", exc_info=exception)
            raise ValueError
        except TypeError as exception:
            log(CRITICAL, "Password not provided.", exc_info=exception)
            raise ValueError
        except ValueError as exception:
            log(CRITICAL, "Invalid private key data.", exc_info=exception)
            raise ValueError
        else:
            if mode == "consumable":
                self.private_key_consumable = private_key
            else:
                self.private_key_operator = private_key

    def _load_public_key(self, mode):
        """Loads public key from file.
        """
        if mode == "consumable":
            key_file = PUBLIC_KEY_FILE_CONSUMABLE
        else:
            key_file = PUBLIC_KEY_FILE_OPERATOR

        try:
            with open(key_file, "rb") as public_key_file:
                public_key = serialization.load_pem_public_key(public_key_file.read(), backend=self.backend)
        # ValueErrors are risen in case of any other exceptions in order to be caught as plain encryption errors.
        except FileNotFoundError as exception:
            log(CRITICAL, "Public key file not found.", exc_info=exception)
            raise ValueError
        except ValueError as exception:
            log(CRITICAL, "Invalid public key data.", exc_info=exception)
            raise ValueError
        else:
            if mode == "consumable":
                self.public_key_consumable = public_key
            else:
                self.public_key_operator = public_key

    def encrypt(self, data_for_encryption, mode="consumable"):
        """Encrypts provided data.

        Args:
            data_for_encryption (string): Data for encryption

        Returns:
            string: Urlsafe B64 encoded data
        """
        if mode == "consumable":
            if self.public_key_consumable is None:
                self._load_public_key(mode)
            public_key = self.public_key_consumable
        else:
            if self.public_key_operator is None:
                self._load_public_key(mode)
            public_key = self.public_key_operator

        encrypted_data = public_key.encrypt(
            force_bytes(data_for_encryption),
            OAEP(mgf=MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
        )
        return force_str(base64.urlsafe_b64encode(encrypted_data))

    def decrypt(self, encrypted_data, mode="consumable"):
        """Decrypts provided data.

        Args:
            encrypted_data (string): Data for decryption

        Returns:
            string: Decrypted data
        """
        if mode == "consumable":
            if self.private_key_consumable is None:
                self._load_private_key(mode)
            private_key = self.private_key_consumable
        else:
            if self.private_key_operator is None:
                self._load_private_key(mode)
            private_key = self.private_key_operator

        decrypted_data = private_key.decrypt(
            base64.urlsafe_b64decode(encrypted_data),
            OAEP(mgf=MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
        )
        return force_str(decrypted_data)

    def sign(self, data_to_sign, mode="consumable"):
        """Signs the provided data using private key.

        Args:
            data_to_sign (string): Data for signing

        Returns:
            string: Urlsafe B64 encoded signature
        """
        if mode == "consumable":
            private_key = self.private_key_consumable
        else:
            private_key = self.private_key_operator

        signature = private_key.sign(
            data_to_sign, padding.PSS(mgf=MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH), hashes.SHA256(),
        )
        return force_str(base64.urlsafe_b64encode(signature))

    def verify(self, signed_data, signature, mode="consumable"):
        """Verifies provided data and signature using public key.

        Args:
            signed_data (string): Signed data
            signature (string): Corresponding signature
        """
        if mode == "consumable":
            public_key = self.public_key_consumable
        else:
            public_key = self.public_key_operator

        try:
            public_key.verify(
                base64.urlsafe_b64decode(signature),
                signed_data,
                padding.PSS(mgf=MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                hashes.SHA256(),
            )
        except InvalidSignature as exception:
            log(CRITICAL, "Invalid signature.", exc_info=exception)
            raise InvalidSignature
        else:
            pass

    @staticmethod
    def generate_id(length=16):
        """This method is used for secret and serial IDs generation. It is used
        in QR code generator program, but since the backends here and there are
        the same, this function is also included here.

        Args:
            length (int, optional): Desired length of the output. Defaults to 16.

        Returns:
            string: Random ID made of digits, uppercase and lowercase letters
        """
        return force_str("".join(secrets.choice(string.ascii_letters + string.digits) for i in range(length)))


class KeyExchange:
    """Class responsible for Ed25519 key exchange between API and machine software
    This ensures that the calls which modify consumable amounts etc. are sent
    from trusted source (MM3D product).
    """

    def __init__(self):
        """Init the cryptography backend.
        """
        self.backend = default_backend()

    def begin_key_exchange(self):
        """This function generates a new X25519 key and returns it for exchange with a peer.

        Returns:
            tuple(bytes, bytes): Serialized X25519 public key, salt
        """

        self.private_key = X25519PrivateKey.generate()
        public_key = self.private_key.public_key()
        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )
        self.salt = os.urandom(16)

        return (
            force_str(base64.urlsafe_b64encode(force_bytes(public_bytes))),
            force_str(base64.urlsafe_b64encode(force_bytes(self.salt))),
        )

    def finish_key_exchange(self, piid, peer_public_key):
        """Finish the key exchange process and generate the final key.

        Args:
            peer_public_key (bytes): Serialized public key returned from begin_key_exchange() by peer
        """

        info = bytes(piid.encode("UTF-8"))
        shared_key = self.private_key.exchange(
            X25519PublicKey.from_public_bytes(force_bytes(base64.urlsafe_b64decode(force_bytes(peer_public_key))))
        )
        derived_key = HKDF(
            algorithm=hashes.SHA256(), length=32, salt=self.salt, info=info, backend=self.backend
        ).derive(shared_key)
        self.private_key = ed25519.Ed25519PrivateKey.from_private_bytes(derived_key)
        self.public_key = self.private_key.public_key()

    def sign(self, data):
        """Sign the passed data with shared Ed25519 key.

        Args:
            data (string): Data to sign

        Returns:
            bytes: Signature of provided data
        """
        return self.key.sign(bytes(data))

    def verify(self, data, signature):
        """Verify if the provided signature is valid.

        Args:
            data (string): Data for verification
            signature (string): Signature for data verification
        """
        self.public_key.verify(self.to_bytes(signature), bytes(data, "UTF-8"))

    def to_bytes(self, data):
        """Converts provided data from string to url-safe Base64 encoded bytes.

        Args:
            data (string): Data for conversion

        Returns:
            bytes: Encoded and converted data
        """
        return force_bytes(base64.urlsafe_b64decode(force_bytes(data)))

    def to_text(self, data):
        """Converts provided data from Base64 encoded bytes to string.

        Args:
            data (bytes): Data for conversion

        Returns:
            string: Decoded bytes
        """
        return force_str(base64.urlsafe_b64encode(force_bytes(data)))


class ArduinoChaCha:
    def generate_key(self):
        """Generates ChaCha20Poly1305 key. Unused in API code, key is stored
        in database, but the method is here just to have it defined somewhere.

        Returns:
            string: ChaCha20Poly1305 key in HEX format
        """
        return ChaCha20Poly1305.generate_key().hex()

    def encrypt_data(self, arduino_uid, secret, key):
        """Encrypts arduino_uid and a secret string using the provided key
        to create data that will be passed to an Arduino and then decrypted
        there (which will confirm the auth in case the decryption and data
        comparison succeeds).

        Args:
            arduino_uid (string): Arduino's unique ID
            secret (string): Arduino's unique secret string
            key (string): Arduino's unique cryptography key

        Returns:
            string: Encrypted data in hex:hex format
        """
        chacha = ChaCha20Poly1305(bytes.fromhex(key))
        nonce = os.urandom(12)
        encrypted = chacha.encrypt(nonce, bytes(arduino_uid + ";" + secret + ";", "UTF-8"), None)
        # Intentional use of ":" instead of ";", it's replaced later in Pi's app
        return nonce.hex() + ":" + encrypted.hex()
