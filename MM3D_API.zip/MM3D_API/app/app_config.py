HOST = "0.0.0.0"
# HOST = "127.0.0.1"

LOG_FILE = "error.log"
LOG_CONFIG_FILE = "app/logging.conf"

# Taken from Firebase app project's page
PROJECT_ID = "metalmaker3d-app"
PROJECT_ISS = "https://securetoken.google.com/metalmaker3d-app"

KEY_SIZE = 2048
KEY_ENCRYPTION_PW_CONSUMABLE = b"KQPFoQsFipuchdJK"
KEY_ENCRYPTION_PW_OPERATOR = b"3Uwn5pwarc3rKSOh"
PRIVATE_KEY_FILE_CONSUMABLE = "./private_key_consumable.pem"
PUBLIC_KEY_FILE_CONSUMABLE = "./public_key_consumable.pem"
PRIVATE_KEY_FILE_OPERATOR = "./private_key_operator.pem"
PUBLIC_KEY_FILE_OPERATOR = "./public_key_operator.pem"


class Config(object):
    SQLALCHEMY_ECHO = True

    # These credentials are used to connect to a locally set database.
    # It used to be a remote database on a real hosting, but due to the fact
    # that it was a private server, these credentials had to be removed
    # and the database replaced with one set up locally.
    # These credentials give access to the root account. In real use,
    # there should be a public account with permissions set in such way,
    # that there is no way for any user to delete any records.
    dialect = "mysql"
    driver = ""
    username = "root"
    password = ""
    host = "localhost"
    port = 3306
    database = "mm3d2"

    SQLALCHEMY_DATABASE_URI = f"{dialect}{driver}://{username}:{password}@{host}:{port}/{database}"

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"connect_args": {"connect_timeout": 5}}

    # Adjust these to fix pool overflows and etc.
    SQLALCHEMY_POOL_RECYCLE = 299
    SQLALCHEMY_POOL_TIMEOUT = 20
