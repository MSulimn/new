from binascii import Error as BinasciiError
from datetime import datetime
from flask import jsonify
from flask import request as flask_request
from logging import CRITICAL, ERROR, WARNING, INFO
from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound

from app import api_app, db, rsa
from app.auth_decorators import google_token_required
from app.constants import (
    STATUS_FAILED,
    STATUS_SUCCESS,
    CODE_SUCCESS,
    CODE_NEW_USER,
    CODE_MULTIPLE_RESULTS_FOUND,
    CODE_NO_RESULTS_FOUND,
    CODE_CONSUMABLE_BASE64_DECRYPTION_ERROR,
    CODE_CONSUMABLE_ENCRYPTED_DATA_MISMATCH,
    CODE_CONSUMABLE_ENCRYPTED_DATA_DECRYPTION_ERROR,
    CODE_CONSUMABLE_REASSIGNMENT,
    CODE_CONSUMABLE_REASSIGNMENT_DIFFERENT,
    CODE_CONSUMABLE_ASSIGNMENT_PARTIAL_DATA_PRESENT,
    CODE_OPERATOR_ENCRYPTED_DATA_MISMATCH,
    CODE_OPERATOR_BASE64_DECRYPTION_ERROR,
    CODE_OPERATOR_ENCRYPTED_DATA_DECRYPTION_ERROR,
    CODE_OPERATOR_REASSIGNMENT,
    CODE_MACHINE_REASSIGNMENT,
    CODE_UNCAUGHT_EXCEPTION,
    CODE_USER_EXISTENT,
    USER,
    ADMIN,
    PENDIND_USER,
    NO_ASSIGNED_USER
)
from app.logger import log
from app.models import (
    Client,
    Consumable,
    Machine,
    Operator,
    Order,
    User,
    ConsumablesAssignmentDetailsScheme,
    ConsumablesDetailsScheme,
    ConsumablesListScheme,
    ListMachinesScheme,
    ConsumablesAmount,
    IDClientScheme,
    ConsumablesDetailsClientScheme,
    ListUsersScheme
)


@api_app.route("/authenticate/", methods=["POST"])
@google_token_required
def authenticate(**kwargs):
    """Authenticate user at sign-in. Check if it's a returning user
    (exists in database) or not. If not, app will show a proper
    first-time-user popup.

    Returns:
        JSONObject: User status information
    """
    try:
        query = (
            db.session.query(User)
            .filter(User.UID == kwargs["uid"])
            .filter(User.REMOVED == 0)
            .one()
        )

    except NoResultFound:
        new_user = User(UID=kwargs["uid"])
        db.session.add(new_user)
        db.session.commit()
        db.session.close()
        log(INFO, "NewUserAdded")
        return jsonify({"status": STATUS_SUCCESS, "code": CODE_NEW_USER}), 200

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        try:
            query.LAST_LOGIN = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            db.session.merge(query)
            db.session.commit()
            db.session.close()
            log(INFO, "ReturningUserLogged")
            return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500


@api_app.route("/authenticate_user/<new>/<name>/<email>", methods=["POST"])
@google_token_required
def authenticate_user(new, name, email,*args, **kwargs):
    """Authenticate user at sign-in, or create a new client number in case it is a new user
    returning. if new = 1 means that it is a new user and create new client number. Otherwise,
    just authenticate the user and return the user data.

    """

    new = int(new)
    request_data = flask_request.get_json()
    print(request_data['url'])
    url = request_data['url']
    try:
        query = (
            db.session.query(User)
            .filter(User.UID == kwargs["uid"])
            .filter(User.REMOVED == 0)
            .one()
        )
    except NoResultFound as exception:
        if new:
            new_user = User(UID=kwargs["uid"],
                            ID_CLIENT= 0,
                            NAME = name,
                            EMAIL = email,
                            URL = url,
                            ROLE="NA")
            db.session.add(new_user)
            db.session.commit()
            db.session.close()
            log(INFO, "NewUserAdded")
            return jsonify({"status": STATUS_SUCCESS, "code": CODE_NEW_USER}), 200
        else:
            db.session.close()
            log(CRITICAL, "UserNotFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        if not new:
            try:
                query.LAST_LOGIN = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                query.URL = url
                db.session.merge(query)
                db.session.commit()
                role = query.ROLE
                id_client = str(query.ID_CLIENT)
                db.session.close()
                log(INFO, "ReturningUserLogged")
                return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS, "role_client": role, "id_client":id_client}), 200

            except Exception as exception:
                db.session.close()
                log(CRITICAL, "Exception", exception, True)
                return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500
        else:
            db.session.close()
            log(INFO, "User Existent")
            return jsonify({"status": STATUS_FAILED, "code": CODE_USER_EXISTENT}), 500



@api_app.route("/consult_client_name/<name>/<action>", methods=["POST"])
@google_token_required
def consult_client_name(name, action, **kwargs):
    try:
        query = (
            db.session.query(Client)
                .filter(Client.ADDRESS == name)
                .one()
        )
    except NoResultFound as exception:
        if action == "join":
            log(CRITICAL, "Client name not registered", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500
        elif action == "new":
            try:
            #The client name is available to be created
                log(INFO, "Client name available ")
                return jsonify({"status": STATUS_SUCCESS, "code": CODE_NEW_USER}), 200
            except:
                return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        else:
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_USER_EXISTENT}), 500

    except MultipleResultsFound as exception:
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500
    else:
        if action == "join":
            #The client name is registered to join
            log(INFO, "Client to join existent")
            return jsonify({"status": STATUS_SUCCESS, "code": CODE_USER_EXISTENT, "id_client":query.ID}), 200
        elif action == "new":
            log(CRITICAL, "The client name not available.")
            return jsonify({"status": STATUS_FAILED, "code": CODE_USER_EXISTENT}), 500
        else:
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

@api_app.route("/create_new_client/<name>", methods=["POST"])
@google_token_required
def create_new_client(name, **kwargs):
    try:
        query = (
            db.session.query(Client)
        )
        new_client = Client(ADDRESS=name)
        db.session.add(new_client)
        db.session.commit()
        db.session.close()
        log(INFO, "NewClientCreated")

        try:
            query = (
                db.session.query(Client)
                .filter(Client.ADDRESS == name)
                .one()
            )
            client_id = query.ID
            db.session.close()
            log(INFO, "Client name created succesfully")

            try:
                query = (
                    db.session.query(User)
                    .filter(User.UID == kwargs["uid"])
                    .one()
                    )
                query.ID_CLIENT = client_id
                query.ROLE = "A"
                db.session.merge(query)
                db.session.commit()
                db.session.close()
                log(INFO, "Client name assigned succesfully")
                return jsonify({"status": STATUS_SUCCESS, "code": CODE_NEW_USER, "role_client": "A", "id_client": client_id}), 200

            except Exception as exception:
                db.session.close()
                log(CRITICAL, "Exception", exception, True)
                return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        except Exception as exception:
            #Todo delete register of client
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500





    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500


@api_app.route("/listMachines/", methods=["POST"])
@google_token_required
def list_machines(**kwargs):
    """Return complete user's machine list.

    Returns:
        JSONArray: Complete user's machine list or none status
    """


    try:
        query = (
            db.session.query(Machine)
            .filter(User.UID == (kwargs["uid"]))
            .filter(User.ID_CLIENT == Machine.ID_CLIENT)
            .filter(User.REMOVED == 0)
            .all()
        )

    # try:
    #     query = (
    #         db.session.query(Operator)
    #         .filter(Machine.ID == Operator.ID_MACHINE)
    #         .filter(Operator.ID_USER == User.ID)
    #         .filter(Operator.REMOVED == 0)
    #         .filter(User.UID == (kwargs["uid"]))
    #         .order_by(Operator.ID_MACHINE.asc())
    #         .all()
    #     )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(ListMachinesScheme(many=True).dump(query))
        print(response)
        return jsonify(response), 200



@api_app.route("/listUsers/<client_id>", methods=["POST"])
@google_token_required
def list_users(client_id, **kwargs):

    try:
        query = (
            db.session.query(User)
            .filter(User.ID_CLIENT == client_id)
            .filter(User.REMOVED == 0)
            .filter(User.UID != (kwargs["uid"]))
            .all()
        )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(ListUsersScheme(many=True).dump(query))
        print(response)
        return jsonify(response), 200


@api_app.route("/removeMachine/<machine_id>", methods=["POST"])
@google_token_required
def remove_machine(machine_id, **kwargs):
    """Remove machine (by ID) from user's machine list (set REMOVED value
    in Operators table at corresponding user record).

    Args:
        machine_id (string): Machine's ID

    Returns:
        JSONObject: Machine unbinding status or exception
    """
    try:
        query = (
            db.session.query(Operator)
            .filter(Operator.ID_USER == User.ID)
            .filter(Operator.ID_MACHINE == machine_id)
            .filter(Operator.REMOVED == 0)
            .filter(User.UID == kwargs["uid"])
            .one()
        )

    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        try:
            query.REMOVED = 1
            db.session.merge(query)
            db.session.commit()
            db.session.close()
            log(INFO, "MachineUnbound")
            return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500


@api_app.route("/deleteAccount/", methods=["POST"])
@google_token_required
def delete_account(**kwargs):
    """Delete user's account (set REMOVED flag). First, get all assignments
    of user as operator and set these records' REMOVED flags as True.
    Next, if nothing happened so far, get the user's record from Users
    table and set REMOVED flag as True there too. Return an error
    information in case there are multiple records of current user
    with REMOVED flags set to False.

    Returns:
        JSONObject: User account deletion status or exception
    """
    try:
        query = (
            db.session.query(Operator)
            .filter(Operator.ID_USER == User.ID)
            .filter(Operator.REMOVED == 0)
            .filter(User.UID == kwargs["uid"])
            .all()
        )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        for element in query:
            element.REMOVED = 1
            db.session.merge(element)
        db.session.flush()

        try:
            query = (
                db.session.query(User)
                .filter(User.UID == kwargs["uid"])
                .filter(User.REMOVED == 0)
                .one()
            )

        except NoResultFound as exception:
            db.session.close()
            log(ERROR, "NoResultFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

        except MultipleResultsFound as exception:
            db.session.close()
            log(ERROR, "MultipleResultsFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        else:
            try:
                query.REMOVED = 1
                query.REMOVED_AT = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                db.session.merge(query)
                db.session.commit()
                db.session.close()
                log(INFO, "AccountDeleted")
                return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

            except Exception as exception:
                db.session.close()
                log(CRITICAL, "Exception", exception, True)
                return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500


@api_app.route("/getConsumableList/<machine_id>", methods=["POST"])
@google_token_required
def get_consumable_list(machine_id, **kwargs):
    """Gets and returns a list of consumables assigned to a machine
    currently selected in mobile app. It also lists consumables that
    were removed in RPi app (flag REMOVED set to 1).

    Args:
        machine_id (int): Machine serial number (ID)

    Returns:
        JSONArray / JSONObject: In case of success, data is returned as
        JSONArray of two JSONArrays containing JSONObjects which contain
        info about the outcome of the request and machine's consumable
        list data. In case of failure there is a single JSONObject
        returned which contains status and code info about the request
        outcome.
    """
    try:
        query = (
            db.session.query(
                Consumable.NAME,
                Consumable.ID.label("ID_CONSUMABLE"),
                Order.ID.label("ID_ORDER"),
                Order.ID_SERIAL,
                Order.DATE_ASSIGNED
            )
            .filter(User.UID == (kwargs["uid"]))
            .filter(User.ID_CLIENT == Machine.ID_CLIENT)
            .filter(User.REMOVED == 0)
            .filter(Order.ID_CLIENT == User.ID_CLIENT)
            .filter(Order.ID_CONSUMABLE == Consumable.ID)
            .order_by(Order.ID.desc())
            .all()
        )
    # try:
    #     query = (
    #         db.session.query(
    #             Consumable.NAME,
    #             Consumable.ID.label("ID_CONSUMABLE"),
    #             Order.ID.label("ID_ORDER"),
    #             Order.ID_SERIAL,
    #             Order.DATE_ASSIGNED
    #         )
    #         .filter(Order.ID_ASSIGNED_MACHINE == machine_id)
    #         .filter(Order.ID_CONSUMABLE == Consumable.ID)
    #         .order_by(Order.DATE_ASSIGNED.desc())
    #         .all()
    #     )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(ConsumablesListScheme(many=True).dump(query))
        print(response)
        print("----------------")
        return jsonify(response), 200


@api_app.route("/getConsumableDetails/<consumable_id>/<order_id>", methods=["POST"])
@google_token_required
def get_consumable_details(consumable_id, order_id, **kwargs):
    """Returns detailed information about selected consumable.

    Args:
        consumable_id (int): Consumable ID (from Consumables table,
        not Order)

    Returns:
        JSONArray / JSONObject: In case of success, data is returned as
        JSONArray of two JSONArrays containing JSONObjects which contain
        info about the outcome of the request and selected consumable's
        details. In case of failure there is a single JSONObject returned
        which contains status and code info about the request outcome.
    """
    try:
        query = (
            db.session.query(
                Consumable.NAME,
                Consumable.TYPE,
                Consumable.TEMP_CRUCIBLE,
                Consumable.TEMP_DIES,
                Order.ID_SERIAL,
                Order.LIFESPAN,
                Order.LIFESPAN_LEFT,
                Order.DATE_ASSIGNED,
                Order.ASSIGNED_MATERIAL,
                Order.ASSIGNED_MODEL,
                Order.REMOVED,
            )
            .filter(User.UID == (kwargs["uid"]))
            .filter(Order.ID_CLIENT == User.ID_CLIENT)
            .filter(Consumable.ID == consumable_id)
            .filter(Order.ID == order_id)
            .all()
        )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(ConsumablesDetailsScheme(many=True).dump(query))
        return jsonify(response), 200


@api_app.route("/assignOperator/<machine_id>/<machine_type>/<serial_id>/<encrypted_data>", methods=["POST"])
@google_token_required
def assign_operator(machine_id, machine_type, serial_id, encrypted_data, **kwargs):
    """Assign user (identified by UID in token) as a new operator to a machine.

    Args:
        machine_id (string): ID of the mashine that the user is assigned to

    Returns:
        JSONObject: JSONObject containing user assignment status or exception
    """
    try:
        # machine_id;machine_type;serial_id;secret_id;pi_id
        decrypted = rsa.decrypt(encrypted_data, mode="machine").split(";")
        if machine_id == decrypted[0] and machine_type == decrypted[1] and serial_id == decrypted[2]:
            secret_id = decrypted[3]
            pi_id = decrypted[4]
        else:
            log(ERROR, "EncryptedDataMismatch")
            return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_ENCRYPTED_DATA_MISMATCH}), 500

    except BinasciiError as exception:  # Failed to convert from Base64
        log(ERROR, "Base64DecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_BASE64_DECRYPTION_ERROR}), 500

    except ValueError as exception:  # Decryption failed (in any way)
        log(ERROR, "EncryptedDataDecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_ENCRYPTED_DATA_DECRYPTION_ERROR}), 500

    except Exception as exception:  # Any other possible error should be catched here
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        # Check if machine with given type, serial, secret and pi_id exist
        try:
            onetime_query = (
                db.session.query(Machine)
                .filter(Machine.ID == machine_id)
                .filter(Machine.ID_SERIAL == serial_id)
                .filter(Machine.ID_SECRET == secret_id)
                .filter(Machine.ID_PI == pi_id)
                .filter(Machine.MACHINE_TYPE == machine_type)
                .one()
            )
            db.session.expire(onetime_query)

        except NoResultFound as exception:
            db.session.close()
            log(ERROR, "NoResultFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

        except MultipleResultsFound as exception:
            db.session.close()
            log(ERROR, "MultipleResultsFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        else:
            try:
                query = (
                    db.session.query(Operator)
                    .filter(Operator.ID_USER == User.ID)
                    .filter(Operator.ID_MACHINE == machine_id)
                    .filter(Operator.REMOVED == 0)
                    .filter(User.UID == kwargs["uid"])
                    .one()
                )

            except NoResultFound:
                log(INFO, "AddNewOperator")

                try:
                    query = Operator()
                    query.ID_USER = (
                        db.session.query(User).filter(User.UID == kwargs["uid"]).filter(User.REMOVED == 0).one().ID
                    )

                except NoResultFound as exception:
                    db.session.close()
                    log(ERROR, "NoResultFound", exception, False)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

                except MultipleResultsFound as exception:
                    db.session.close()
                    log(ERROR, "MultipleResultsFound", exception, False)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

                except Exception as exception:
                    db.session.close()
                    log(CRITICAL, "Exception", exception, True)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

                else:
                    try:
                        query.ID_MACHINE = machine_id
                        db.session.merge(query)
                        db.session.commit()
                        db.session.close()
                        log(INFO, "OperatorAssigned")
                        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

                    except Exception as exception:
                        db.session.close()
                        log(CRITICAL, "Exception", exception, True)
                        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

            except MultipleResultsFound as exception:
                db.session.close()
                log(ERROR, "MultipleResultsFound", exception, False)
                return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

            except Exception as exception:
                db.session.close()
                log(CRITICAL, "Exception", exception, True)
                return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

            else:
                db.session.close()
                log(WARNING, "OperatorReassignment")
                return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_REASSIGNMENT}), 500


@api_app.route("/assignMachineToClient/<machine_id>/<machine_type>/<serial_id>/<encrypted_data>/<client_id>", methods=["POST"])
@google_token_required
def assign_machine_to_client(machine_id, machine_type, serial_id, encrypted_data, client_id, **kwargs):
    """Assign user (identified by UID in token) as a new operator to a machine.

    Args:
        machine_id (string):

    Returns:
        JSONObject: JSONObject containing user assignment status or exception
    """
    try:
        # machine_id;machine_type;serial_id;secret_id;pi_id
        decrypted = rsa.decrypt(encrypted_data, mode="machine").split(";")
        if machine_id == decrypted[0] and machine_type == decrypted[1] and serial_id == decrypted[2]:
            secret_id = decrypted[3]
            pi_id = decrypted[4]
        else:
            log(ERROR, "EncryptedDataMismatch")
            return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_ENCRYPTED_DATA_MISMATCH}), 500

    except BinasciiError as exception:  # Failed to convert from Base64
        log(ERROR, "Base64DecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_BASE64_DECRYPTION_ERROR}), 500

    except ValueError as exception:  # Decryption failed (in any way)
        log(ERROR, "EncryptedDataDecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_OPERATOR_ENCRYPTED_DATA_DECRYPTION_ERROR}), 500

    except Exception as exception:  # Any other possible error should be catched here
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        # Check if machine with given type, serial, secret and pi_id exist
        try:
            query = (
                db.session.query(Machine)
                .filter(Machine.ID == machine_id)
                .filter(Machine.ID_SERIAL == serial_id)
                .filter(Machine.ID_SECRET == secret_id)
                .filter(Machine.ID_PI == pi_id)
                .filter(Machine.MACHINE_TYPE == machine_type)
                .one()
            )
        except NoResultFound as exception:
            db.session.close()
            log(ERROR, "NoResultFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

        except MultipleResultsFound as exception:
            db.session.close()
            log(ERROR, "MultipleResultsFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500


        else:
            if query.ID_CLIENT is None:
                try:
                    query.ID_CLIENT = client_id
                    db.session.merge(query)
                    db.session.commit()
                    db.session.close()
                    log(INFO, "MachineAssignedToClient")
                    return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

                except Exception as exception:
                    db.session.close()
                    log(CRITICAL, "Exception", exception, True)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

            elif query.ID_CLIENT is int(client_id):
                db.session.close()
                log(WARNING, "MachineReassignment")
                return jsonify({"status": STATUS_FAILED, "code": CODE_MACHINE_REASSIGNMENT}), 500

            else:
                db.session.close()
                log(ERROR, "MachineAssignmentParialDataPresent")
                return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500




@api_app.route("/getConsumableAssignmentDetails/<order_id>/<serial_id>", methods=["POST"])
@google_token_required
def get_consumable_assignment_details(order_id, serial_id, **kwargs):
    """This method is meant to return "assignment details" which just mean
    some more detailed information about consumable (eg. melting temperature
    or lifespan) following the scheme defined in
    ConsumablesAssignmentDetailsScheme. User sees that information on the
    screen after scanning the QR code and then decides if everything is okay
    and if he/she wants to proceed. If so, then assign_consumable method will
    be called.
    Function is called using both order_id and serial_id for additional
    authentication.

    Args:
        order_id (int): Order identification number
        serial_id (string): Consumable's 16 byte unique serial identificator

    Returns:
        JSONArray / JSONObject: In case of success, data is returned as
        JSONArray of two JSONObjects which contain info about the outcome
        of the request and scanned consumable's details. In case of failure
        there is a single JSONObject returned which contains status and code
        info about the request outcome.
    """
    try:
        query = (
            db.session.query(Consumable.NAME, Consumable.TYPE, Consumable.LIFESPAN, Consumable.KEY_CONSUMABLE)
            .filter(Order.ID == order_id)
            .filter(Order.ID_SERIAL == serial_id)
            .filter(Order.ID_CONSUMABLE == Consumable.ID)
            .one()
        )

    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        log(INFO, "ConsumableDetailsRequested")
        response = [{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]
        response.append(ConsumablesAssignmentDetailsScheme(many=False).dump(query))
        return jsonify(response), 200


@api_app.route("/assignConsumable/<machine_id>/<order_id>/<serial_id>/<encrypted_data>", methods=["POST"])
@google_token_required
def assign_consumable(machine_id, order_id, serial_id, encrypted_data, **kwargs):
    """This function decrypts the provided data first and then, if order_id
    and serial_id match the ones in encrypted data, it utilizes the secret_id
    also contained in encrypted data to assign the given consumable to
    the machine which is currently selected in MM3D app on user's phone.

    Args:
        machine_id (int): ID of machine the consumable has to be assigned to
        order_id (int): ID of the order corresponding to given consumable
        serial_id (string): Serial ID of the consumable
        encrypted_data (string): Encrypted data from consumable's QR code

    Returns:
        JSONObject: JSONObject containing status information
    """
    try:
        # order_id;serial_id;secret_id
        decrypted = rsa.decrypt(encrypted_data).split(";")
        if order_id == decrypted[0] and serial_id == decrypted[1]:
            secret_id = decrypted[2]
        else:
            log(ERROR, "EncryptedDataMismatch")
            return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_ENCRYPTED_DATA_MISMATCH}), 500

    except BinasciiError as exception:  # Failed to convert from Base64
        log(ERROR, "Base64DecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_BASE64_DECRYPTION_ERROR}), 500

    except ValueError as exception:  # Decryption failed (in any way)
        log(ERROR, "EncryptedDataDecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_ENCRYPTED_DATA_DECRYPTION_ERROR}), 500

    except Exception as exception:  # Any other possible error should be catched here
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        try:
            query = (
                db.session.query(Order)
                .filter(Order.ID == order_id)
                .filter(Order.ID_SERIAL == serial_id)
                .filter(Order.ID_SECRET == secret_id)
                .one()
            )

        except NoResultFound as exception:
            db.session.close()
            log(ERROR, "NoResultFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

        except MultipleResultsFound as exception:
            db.session.close()
            log(ERROR, "MultipleResultsFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        else:
            if query.DATE_ASSIGNED is None and query.ID_ASSIGNED_MACHINE is None:
                try:
                    query.ID_ASSIGNED_MACHINE = machine_id
                    query.DATE_ASSIGNED = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    db.session.merge(query)
                    db.session.commit()
                    db.session.close()
                    log(INFO, "ConsumableAssigned")
                    return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

                except Exception as exception:
                    db.session.close()
                    log(CRITICAL, "Exception", exception, True)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

            elif query.DATE_ASSIGNED is not None and str(query.ID_ASSIGNED_MACHINE) == machine_id:
                db.session.close()
                log(WARNING, "ConsumableReassignment")
                return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_REASSIGNMENT}), 500

            elif (
                query.DATE_ASSIGNED is not None
                and query.ID_ASSIGNED_MACHINE is not None
                and str(query.ID_ASSIGNED_MACHINE) != machine_id
            ):
                db.session.close()
                log(WARNING, "ConsumableReassignmentDifferent")
                return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_REASSIGNMENT_DIFFERENT}), 500

            else:
                db.session.close()
                log(ERROR, "ConsumableAssignmentParialDataPresent")
                return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_ASSIGNMENT_PARTIAL_DATA_PRESENT}), 500


@api_app.route("/assignConsumableToClient/<machine_id>/<order_id>/<serial_id>/<encrypted_data>/<key_consumable>/<client_id>/<amountConsumable>", methods=["POST"])
@google_token_required
def assign_consumableToClient(machine_id, order_id, serial_id, encrypted_data, key_consumable, client_id,amountConsumable, **kwargs):
    """This function decrypts the provided data first and then, if order_id
    and serial_id match the ones in encrypted data, it utilizes the secret_id
    also contained in encrypted data to assign the given consumable to
    the machine which is currently selected in MM3D app on user's phone.

    Args:
        machine_id (int): ID of machine the consumable has to be assigned to
        order_id (int): ID of the order corresponding to given consumable
        serial_id (string): Serial ID of the consumable
        encrypted_data (string): Encrypted data from consumable's QR code

    Returns:
        JSONObject: JSONObject containing status information
    """
    try:
        # order_id;serial_id;secret_id
        decrypted = rsa.decrypt(encrypted_data).split(";")
        if order_id == decrypted[0] and serial_id == decrypted[1]:
            secret_id = decrypted[2]
        else:
            log(ERROR, "EncryptedDataMismatch")
            return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_ENCRYPTED_DATA_MISMATCH}), 500

    except BinasciiError as exception:  # Failed to convert from Base64
        log(ERROR, "Base64DecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_BASE64_DECRYPTION_ERROR}), 500

    except ValueError as exception:  # Decryption failed (in any way)
        log(ERROR, "EncryptedDataDecryptionError", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_ENCRYPTED_DATA_DECRYPTION_ERROR}), 500

    except Exception as exception:  # Any other possible error should be catched here
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        try:
            query = (
                db.session.query(Order)
                .filter(Order.ID == order_id)
                .filter(Order.ID_SERIAL == serial_id)
                .filter(Order.ID_SECRET == secret_id)
                .one()
            )

        except NoResultFound as exception:
            db.session.close()
            log(ERROR, "NoResultFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

        except MultipleResultsFound as exception:
            db.session.close()
            log(ERROR, "MultipleResultsFound", exception, False)
            return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        else:
            if query.DATE_ASSIGNED is None and query.ID_CLIENT is None:

                try:
                    query.ID_CLIENT = client_id
                    query.DATE_ASSIGNED = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    db.session.merge(query)
                    log(INFO, "ConsumableAssigned")

                except Exception as exception:
                    db.session.close()
                    log(CRITICAL, "Exception", exception, True)
                    return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500
                else:
                    try:
                        query = (
                                db.session.query(Client)
                                .filter(Client.ID == client_id)
                                .one()
                            )
                        if key_consumable == "AL_A356":
                            query.AL_A356 = query.AL_A356 + float(amountConsumable)
                        elif key_consumable == "AL_C355":
                            query.AL_C355 = query.AL_C355 + float(amountConsumable)
                        elif key_consumable == "AL_A380":
                            query.AL_A380 = query.AL_A380 + float(amountConsumable)
                        elif key_consumable == "ZA_ZA12":
                            query.ZA_ZA12 = query.ZA_ZA12 + float(amountConsumable)
                        elif key_consumable == "ZA_ZA8":
                            query.ZA_ZA8 = query.ZA_ZA8 + float(amountConsumable)
                        elif key_consumable == "ZA_ZA27":
                            query.ZA_ZA27 = query.ZA_ZA27 + float(amountConsumable)
                        else:
                            #Delete date and delete id_client from order
                            return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_REASSIGNMENT_DIFFERENT}), 500

                        db.session.merge(query)
                        db.session.commit()
                        db.session.close()

                        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

                    except:
                        return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_REASSIGNMENT_DIFFERENT}), 500

            elif query.DATE_ASSIGNED is not None and str(query.ID_ASSIGNED_MACHINE) == machine_id:
                db.session.close()
                log(WARNING, "ConsumableReassignment")
                return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_REASSIGNMENT}), 500

            elif (
                query.DATE_ASSIGNED is not None
                and query.ID_CLIENT is not None
                and str(query.ID_CLIENT) != client_id
            ):
                db.session.close()
                log(WARNING, "ConsumableReassignmentDifferent")
                return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_REASSIGNMENT_DIFFERENT}), 500

            else:
                db.session.close()
                log(ERROR, "ConsumableAssignmentParialDataPresent")
                return jsonify({"status": STATUS_FAILED, "code": CODE_CONSUMABLE_ASSIGNMENT_PARTIAL_DATA_PRESENT}), 500


@api_app.route("/getConsumableAmount/<client_id>", methods=["POST"])
@google_token_required
def get_consumable_amount(client_id, **kwargs):

    try:
        query = (
            db.session.query(Client).filter(
                Client.ID == client_id
            )
            .all()
        )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(ConsumablesAmount(many=True).dump(query))
        return jsonify(response), 200




@api_app.route("/getClientId/", methods=["POST"])
@google_token_required
def getClientId(**kwargs):
    """Return complete user's machine list.
    Returns:
        JSONArray: Complete user's machine list or none status
    """
    try:
        query = (
            db.session.query(User)
            .filter(User.UID == (kwargs["uid"]))
            .one()
        )
    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(IDClientScheme(many=False).dump(query))
        return jsonify(response), 200



@api_app.route("/getConsumableDetailsClient/<consumable_name>/", methods=["POST"])
@google_token_required
def get_consumable_details_client(consumable_name,**kwargs):
    try:
        query = (
            db.session.query(Consumable)
            .filter(Consumable.NAME == consumable_name)
            .all()
        )
    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(ConsumablesDetailsClientScheme(many=True).dump(query))
        print(response)
        return jsonify(response), 200

@api_app.route("/set_role_client/<role>", methods=["POST"])
@google_token_required
def set_role_client(role, **kwargs):
    try:
        query = (
            db.session.query(User)
            .filter(User.UID == (kwargs["uid"]))
            .filter(User.REMOVED == 0)
            .one()
        )
    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        query.ROLE = role
        db.session.merge(query)
        db.session.commit()
        db.session.close()
        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

@api_app.route("/attend_user_request/<user_uid>/<client_id>/<response>", methods=["POST"])
@google_token_required
def attend_user_request(user_uid, client_id, response, **kwargs):
    try:
        query = (
            db.session.query(User)
            .filter(User.UID == user_uid)
            .filter(User.REMOVED == 0)
            .filter(User.ROLE == "P")
            .one()
        )
    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        try:
            if response == "accept":
                query.ROLE = "U"
                query.ID_CLIENT = int(client_id)
                db.session.merge(query)
                db.session.commit()
                db.session.close()
            else:
                query.ROLE = "NA"
                query.ID_CLIENT = 0
                db.session.merge(query)
                db.session.commit()
                db.session.close()

            return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200
        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500


@api_app.route("/change_role_user/<client_id>/<user_id>", methods=["POST"])
@google_token_required
def change_role_user(client_id, user_id, **kwargs):
    try:
        query = (
            db.session.query(User)
            .filter(User.ID_CLIENT == int(client_id))
            .filter(User.ID == int(user_id))
            .filter(User.REMOVED == 0)
            .one()
        )

    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        if query.ROLE == USER:
            query.ROLE = ADMIN
        else:
            query.ROLE = USER

        db.session.merge(query)
        db.session.commit()
        db.session.close()
        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200


@api_app.route("/remove_user/<client_id>/<user_id>", methods=["POST"])
@google_token_required
def remove_user(client_id, user_id, **kwargs):
    try:
        query = (
            db.session.query(User)
            .filter(User.ID_CLIENT == int(client_id))
            .filter(User.ID == int(user_id))
            .filter(User.REMOVED == 0)
            .one()
        )
    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:

        query.ROLE = NO_ASSIGNED_USER
        query.ID_CLIENT = 0

        db.session.merge(query)
        db.session.commit()
        db.session.close()
        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200