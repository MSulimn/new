from marshmallow_sqlalchemy import SQLAlchemySchema
from sqlalchemy.dialects.mysql import INTEGER, TINYINT, FLOAT
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import Column, DateTime, Float, ForeignKey, Index, String, text

from app import db, ma

# $ Model generation command:
# sqlacodegen mysql://root:@localhost/freaktal_mm3d

Base = declarative_base()
metadata = Base.metadata


# $ ---------------------------------------------------------------------------- #
# $                                    MODELS                                    #
# $ ---------------------------------------------------------------------------- #


class Arduino(Base):
    __tablename__ = "Arduinos"

    ID = Column(INTEGER(11), primary_key=True)
    ID_MACHINE = Column(ForeignKey("Machines.ID"), nullable=False, index=True)
    ARDUINO_TYPE = Column(INTEGER(11), nullable=False, unique=True)
    ARDUINO_UID = Column(String(18), nullable=False, unique=True)
    SECRET = Column(String(32), nullable=False, unique=True)
    KEY = Column(String(64), nullable=False, unique=True)

    machine = relationship("Machine")


class Client(Base):
    __tablename__ = "Clients"

    ID = Column(INTEGER(11), primary_key=True, unique=True)
    ADDRESS = Column(String(128), nullable=False, unique=True)
    AL_A356 = Column(FLOAT(16,2), nullable=True, default=0.0)
    AL_C355 = Column(FLOAT(16,2), nullable=True, default=0.0)
    AL_A380 = Column(FLOAT(16,2), nullable=True, default=0.0)
    ZA_ZA12 = Column(FLOAT(16,2), nullable=True, default=0.0)
    ZA_ZA8 = Column(FLOAT(16,2), nullable=True, default=0.0)
    ZA_ZA27 = Column(FLOAT(16,2), nullable=True, default=0.0)







class Consumable(Base):
    __tablename__ = "Consumables"

    ID = Column(INTEGER(11), primary_key=True)
    KEY_CONSUMABLE = Column(String(128))
    NAME = Column(String(64), nullable=False, unique=True)
    TYPE = Column(ForeignKey("ConsumableTypes.ID"), nullable=False, index=True)
    LIFESPAN = Column(INTEGER(11))
    DENSITY = Column(Float)
    MELT_PROCESSING = Column(String(64))
    HEAT_TREATMENT = Column(String(64))
    TEMP_CRUCIBLE = Column(INTEGER(11))
    TEMP_DIES = Column(INTEGER(11))
    PRICE = Column(INTEGER(11), nullable=False)

    consumabletype = relationship("ConsumableType")
    # consumabletype = relationship("ConsumableType", foreign_keys=[TYPE])


class ConsumableType(Base):
    __tablename__ = "ConsumableTypes"

    ID = Column(INTEGER(11), primary_key=True)
    TYPE = Column(String(64), nullable=False, unique=True)


class Machine(Base):
    __tablename__ = "Machines"

    ID = Column(INTEGER(11), primary_key=True)
    ID_SERIAL = Column(String(16), nullable=False, unique=True)
    ID_SECRET = Column(String(16), nullable=False, unique=True)
    ID_PI = Column(String(16), nullable=False, unique=True)
    MACHINE_TYPE = Column(ForeignKey("MachineTypes.ID"), nullable=False, index=True)
    ID_CLIENT = Column(ForeignKey("Clients.ID"), nullable=False, index=True)

    client = relationship("Client")
    machinetype = relationship("MachineType")



class MachineType(Base):
    __tablename__ = "MachineTypes"

    ID = Column(INTEGER(11), primary_key=True)
    TYPE = Column(String(32), nullable=False, unique=True)


class Operator(Base):
    __tablename__ = "Operators"
    __table_args__ = (Index("ID_USER", "ID_USER", "ID_MACHINE"),)

    ID = Column(INTEGER(11), primary_key=True)
    ID_USER = Column(ForeignKey("Users.ID"), nullable=False, index=True)
    ID_MACHINE = Column(ForeignKey("Machines.ID"), nullable=False, index=True)
    REMOVED = Column(TINYINT(1), nullable=False, server_default=text("0"))

    machine = relationship("Machine")
    user = relationship("User")


class Order(Base):
    __tablename__ = "Orders"

    ID = Column(INTEGER(11), primary_key=True)
    ID_CLIENT = Column(ForeignKey("Clients.ID"), nullable=False, index=True)
    ID_CONSUMABLE = Column(ForeignKey("Consumables.ID"), nullable=False, index=True)
    ID_SERIAL = Column(String(16), nullable=False, unique=True)
    ID_SECRET = Column(String(16), nullable=False, unique=True)
    LIFESPAN = Column(INTEGER(11), nullable=False)
    LIFESPAN_LEFT = Column(Float, nullable=False)
    DATE_ORDER = Column(DateTime, nullable=False, index=True)
    DATE_ASSIGNED = Column(DateTime)
    ID_ASSIGNED_MACHINE = Column(ForeignKey("Machines.ID"), index=True)
    ASSIGNED_MATERIAL = Column(ForeignKey("Consumables.NAME"), index=True)
    ASSIGNED_MODEL = Column(String(128))
    REMOVED = Column(TINYINT(1), nullable=False, server_default=text("0"))
    AMOUNT = Column(INTEGER(11))

    client = relationship("Client")
    consumable = relationship("Consumable", primaryjoin="Order.ASSIGNED_MATERIAL == Consumable.NAME")
    consumable1 = relationship("Consumable", primaryjoin="Order.ID_CONSUMABLE == Consumable.ID")
    machine = relationship("Machine")


class User(Base):
    __tablename__ = "Users"

    ID = Column(INTEGER(11), primary_key=True)
    ID_CLIENT = Column(ForeignKey("Clients.ID"), nullable=False, index=True)
    ROLE = Column(String(15),server_default = text("P"))
    NAME = Column(String(255))
    EMAIL = Column(String(255))
    URL = Column(String(255))
    UID = Column(String(64), nullable=False, unique=True)
    CREATED_AT = Column(DateTime, nullable=False, server_default=text("current_timestamp()"))
    LAST_LOGIN = Column(DateTime, nullable=False, server_default=text("current_timestamp()"))
    REMOVED_AT = Column(DateTime, nullable=True)
    REMOVED = Column(TINYINT(1), nullable=False, server_default=text("0"))

    client = relationship("Client")

# % ---------------------------------------------------------------------------- #
# %                                    SCHEMES                                   #
# % ---------------------------------------------------------------------------- #


# * ---------------------------- Mobile app schemes ---------------------------- #


class ConsumablesAssignmentDetailsScheme(SQLAlchemySchema):
    class Meta:
        model = Consumable  # ConsumableType
        sqla_session = db.session

    NAME = ma.String()
    TYPE = ma.Integer()
    LIFESPAN = ma.Integer()
    KEY_CONSUMABLE = ma.String()


class ConsumablesDetailsScheme(SQLAlchemySchema):
    class Meta:
        model = Consumable, Order
        sqla_session = db.session

    NAME = ma.String()
    TYPE = ma.Integer()
    TEMP_CRUCIBLE = ma.Integer()
    TEMP_DIES = ma.Integer()
    ID_SERIAL = ma.String()
    LIFESPAN = ma.Integer()
    LIFESPAN_LEFT = ma.Float()
    DATE_ASSIGNED = ma.DateTime("%Y-%m-%d %H:%M:%S")
    ASSIGNED_MATERIAL = ma.String()
    ASSIGNED_MODEL = ma.String()
    REMOVED = ma.Int()

class ConsumablesDetailsClientScheme(SQLAlchemySchema):
    class Meta:
        model = Consumable, Order
        sqla_session = db.session

    NAME = ma.String()
    TYPE = ma.Integer()
    TEMP_CRUCIBLE = ma.Integer()
    TEMP_DIES = ma.Integer()
    DENSITY = ma.Float()
    MELT_PROCESSING = ma.String()
    HEAT_TREATMENT = ma.String()





class ConsumablesListScheme(SQLAlchemySchema):
    class Meta:
        model = ConsumableType, Order
        sqla_session = db.session

    NAME = ma.String()
    ID_CONSUMABLE = ma.Integer()
    ID_ORDER = ma.Integer()
    ID_SERIAL = ma.String()
    DATE_ASSIGNED = ma.Date()


class ListMachinesScheme(SQLAlchemySchema):
    class Meta:
        model = Machine
        sqla_session = db.session

    ID = ma.Integer()

class ListUsersScheme(SQLAlchemySchema):
    class Meta:
        model = User
        sqla_session = db.session

    ID = ma.Integer()
    ID_CLIENT = ma.Integer()
    EMAIL = ma.String()
    URL = ma.String()
    NAME = ma.String()
    ROLE = ma.String()



class IDClientScheme(SQLAlchemySchema):
    class Meta:
        model = User
        sqla_session = db.session

    ID_CLIENT = ma.Integer()
    ROLE = ma.String()


class ConsumablesAmount(SQLAlchemySchema):
    class Meta:
        model = Client
        sqla_session = db.session

    AL_A356 = ma.Float()
    AL_C355 = ma.Float()
    AL_A380 = ma.Float()
    ZA_ZA12 = ma.Float()
    ZA_ZA8 = ma.Float()
    ZA_ZA27 = ma.Float()



# ^---------------------------- Machine app schemes ---------------------------- #


class MachineConsumableListScheme(SQLAlchemySchema):
    class Meta:
        model = ConsumableType, Order
        sqla_session = db.session

    NAME = ma.String()
    TYPE = ma.Integer()
    DENSITY = ma.Float()
    TEMP_CRUCIBLE = ma.Integer()
    TEMP_DIES = ma.Integer()
    ID_SERIAL = ma.String()
    LIFESPAN = ma.Integer()
    LIFESPAN_LEFT = ma.Float()
    ASSIGNED_MATERIAL = ma.String()
    ASSIGNED_MODEL = ma.String()
    KEY_CONSUMABLE = ma.String()
    MELT_PROCESSING = ma.String()



class MachineMaterialListScheme(SQLAlchemySchema):
    class Meta:
        model = Client
        sqla_session = db.session

    AL_A356 = ma.Float()
    AL_C355 = ma.Float()
    AL_A380 = ma.Float()
    ZA_ZA12 = ma.Float()
    ZA_ZA8 = ma.Float()
    ZA_ZA27 = ma.Float()
    NAME = ma.String()
    TYPE = ma.Integer()
    DENSITY = ma.Float()
    TEMP_CRUCIBLE = ma.Integer()
    TEMP_DIES = ma.Integer()
    ID_SERIAL = ma.String()
    LIFESPAN = ma.Integer()
    LIFESPAN_LEFT = ma.Float()
    ASSIGNED_MATERIAL = ma.String()
    ASSIGNED_MODEL = ma.String()
