import logging
from flask import request as flask_request


def log(level, message_appendix, exception=None, traceback=False):
    """Logging function.

    Args:
        level (int): Log level as defined in logging
        message_appendix (string): Message to add after path
        exception (tuple, optional): Exception info if available.
            Defaults to None.
        traceback (bool, optional): Whether to print a traceback
            in case of exception or not. Defaults to False.
    """
    message = flask_request.path + " - " + message_appendix + " - "

    if exception:
        message += str(exception)

    if traceback:
        logging.log(level, message, exc_info=exception)
    else:
        logging.log(level, message)
