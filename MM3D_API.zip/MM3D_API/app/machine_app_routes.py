from cryptography.exceptions import UnsupportedAlgorithm
from flask import jsonify
from flask import request as flask_request
from logging import CRITICAL, ERROR, INFO
from sqlalchemy import asc
from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound

from app import api_app, ke, db, chacha
from app.auth_decorators import google_token_required, ke_signature_required
from app.constants import (
    STATUS_FAILED,
    STATUS_SUCCESS,
    CODE_NO_RESULTS_FOUND,
    CODE_MULTIPLE_RESULTS_FOUND,
    CODE_SUCCESS,
    CODE_CRYPTOGRAPHY_UNSUPPORTED_ALGORITHM,
    CODE_HEADER_DATA_EXCEPTION,
    CODE_UNCAUGHT_EXCEPTION,
    MIN_AMOUNT
)
from app.logger import log
from app.models import (
    Arduino,
    Consumable,
    MachineConsumableListScheme,
    Order,
    Client,
    Machine,
    MachineMaterialListScheme,
    User
)


@api_app.route("/beginKeyExchange/", methods=["POST"])
@google_token_required
def begin_key_exchange(**kwargs):
    """Implements the first step in Ed25519 key exchange - generates
    server-side public key and a salt, which then are returned in JSONObject.
    This key exchange method establishes a secure communication over an
    insecure channel.

    Returns:
        JSONObject: Operation status along with public key and salt in case of success
    """
    try:
        public_key, salt = ke.begin_key_exchange()

    except UnsupportedAlgorithm as exception:
        log(CRITICAL, "UnsupportedAlgorithm", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_CRYPTOGRAPHY_UNSUPPORTED_ALGORITHM}), 500

    except Exception as exception:
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        log(INFO, "KeyExchangeBegun")
        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS, "public_key": public_key, "salt": salt}), 200


@api_app.route("/finishKeyExchange/", methods=["POST"])
@google_token_required
def finish_key_exchange(**kwargs):
    """Gets the provided peer public key along with Raspberry Pi's unique ID
    and finishes up the key exchange process using them.

    Returns:
        JSONArray: Key exchange status information
    """
    try:
        pi_id = flask_request.headers.get("pi_id")
        peer_public_key = flask_request.headers.get("peer_public_key")

    except Exception as exception:
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_HEADER_DATA_EXCEPTION}), 500

    else:
        try:
            ke.finish_key_exchange(pi_id, peer_public_key)

        except UnsupportedAlgorithm as exception:
            log(CRITICAL, "UnsupportedAlgorithm", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_CRYPTOGRAPHY_UNSUPPORTED_ALGORITHM}), 500

        except Exception as exception:
            log(CRITICAL, "Exception", exception, True)
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        else:
            log(INFO, "KeyExchangeFinished")
            return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200


@api_app.route("/machineGetConsumableList/<id_machine>", methods=["POST"])
@google_token_required
@ke_signature_required
def machine_get_consumable_list(id_machine, **kwargs):
    """Returns a list of consumables assigned to selected machine. It is used
    for displaying consumable data in the screens accessible through
    hardware / materials menus but also for getting the data before running
    any of the processes.

    Args:
        id_machine (int): Machine ID

    Returns:
        JSONArray / JSONObject: In case of success, data is returned as
        JSONArray of two JSONArrays containing JSONObjects which contain
        info about the outcome of the request and machine's consumable
        list data. In case of failure there is a single JSONObject
        returned which contains status and code info about the request
        outcome.
    """
    try:
        query = (
            db.session.query(
                Consumable.NAME,
                Consumable.TYPE,
                Consumable.DENSITY,
                Consumable.TEMP_CRUCIBLE,
                Consumable.TEMP_DIES,
                Order.ID_SERIAL,
                Order.LIFESPAN,
                Order.LIFESPAN_LEFT,
                Order.ASSIGNED_MATERIAL,
                Order.ASSIGNED_MODEL,
            )
            .filter(Order.ID_ASSIGNED_MACHINE == id_machine)
            .filter(Order.ID_CONSUMABLE == Consumable.ID)
            .filter(Order.REMOVED == 0)
            .order_by(asc(Order.DATE_ASSIGNED))
            .all()
        )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        response.append(MachineConsumableListScheme(many=True).dump(query))
        # print(response)
        return jsonify(response), 200

@api_app.route("/machineGetMaterialList/<id_machine>", methods=["POST"])
@google_token_required
@ke_signature_required
def machine_get_material_list(id_machine, **kwargs):
    """Returns a list of consumables assigned to selected machine. It is used
    for displaying consumable data in the screens accessible through
    hardware / materials menus but also for getting the data before running
    any of the processes.

    Args:
    Returns:
    """
    try:
        query = (
            db.session.query(Client)
            .filter(Machine.ID == id_machine)
            .filter(Client.ID == Machine.ID_CLIENT)
            .one()
        )

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        amounts = []
        db.session.close()
        response = [[{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}]]
        amounts.append(MachineMaterialListScheme(many=False).dump(query))

        try:
            data_material = []
            for key in amounts[0].keys():
                if amounts[0][key] > MIN_AMOUNT:
                    query = (
                        db.session.query(Consumable)
                        .filter(Consumable.KEY_CONSUMABLE == key)
                        .one()
                        )
                    dictionario = MachineConsumableListScheme(many=False).dump(query)
                    dictionario['LIFESPAN_LEFT'] = amounts[0][key]
                    dictionario['ID_SERIAL'] = ""
                    data_material.append(dictionario)
                else:
                    pass
            response.append(data_material)
            print(response)
        except:
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500
        else:
            return jsonify(response), 200


@api_app.route("/machineAuthenticateArduino/<id_machine>", methods=["POST"])
@google_token_required
@ke_signature_required
def machine_authenticate_arduino(id_machine, **kwargs):
    """Implements Arduino authentication. Raspberry Pi app requests this
    authentication in order to unlock Arduinos' features needed for running
    the processes. The idea is to make it impossible for an abuser to just
    unplug the Arduino, figure out the way of communication (if it isn't
    known by then) and then just run the process by immitating the
    communication with Raspberry Pi.


    Args:
        id_machine (int): Machine ID

    Returns:
        JSONArray: Status and outcome code with ChaCha20Poly1305 encrypted data
        for Arduino to parse in case of success
    """
    data = flask_request.headers.get("signed_data").split(";")

    try:
        query = (
            db.session.query(Arduino.ARDUINO_UID, Arduino.SECRET, Arduino.KEY)
            .filter(Arduino.ID_MACHINE == id_machine)
            .filter(Arduino.ARDUINO_TYPE == data[2])
            .one()
        )

    except NoResultFound as exception:
        db.session.close()
        log(ERROR, "NoResultFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

    except MultipleResultsFound as exception:
        db.session.close()
        log(ERROR, "MultipleResultsFound", exception, False)
        return jsonify({"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}), 500

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

    else:
        db.session.close()
        log(INFO, "ArduinoAuthenticated")
        return (
            jsonify(
                {
                    "status": STATUS_SUCCESS,
                    "code": CODE_SUCCESS,
                    "data": chacha.encrypt_data(arduino_uid=query[0], secret=query[1], key=query[2]),
                }
            ),
            200,
        )


@api_app.route("/machineRemoveConsumable/<id_machine>", methods=["POST"])
@google_token_required
@ke_signature_required
def machine_remove_consumable(id_machine, **kwargs):
    """Implements the possibility to remove a selected consumable (set REMOVED
    flag as 1). Setting that flag as true just makes this consumable invisible
    for the Rasperry Pi app.

    Future feature: implement checking if the deleted consumable is near
    depletion (in case of a material) and if it is, offer a possibility
    to merge it with the same type of consumable if there is an available one.

    Args:
        id_machine (int): Machine ID

    Returns:
        JSONArray: Operation status information
    """
    try:
        serial_id = flask_request.headers.get("serial_id")

    except Exception as exception:
        log(CRITICAL, "Exception", exception, True)
        return jsonify([{"status": STATUS_FAILED, "code": CODE_HEADER_DATA_EXCEPTION}], [{}]), 500

    else:
        try:
            query = (
                db.session.query(Order)
                .filter(Order.ID_ASSIGNED_MACHINE == id_machine)
                .filter(Order.ID_SERIAL == serial_id)
                .filter(Order.REMOVED == 0)
                .one()
            )

        except NoResultFound as exception:
            db.session.close()
            log(ERROR, "NoResultFound", exception, False)
            return jsonify([{"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}], [{}]), 500

        except MultipleResultsFound as exception:
            db.session.close()
            log(ERROR, "MultipleResultsFound", exception, False)
            return jsonify([{"status": STATUS_FAILED, "code": CODE_MULTIPLE_RESULTS_FOUND}], [{}]), 500

        except Exception as exception:
            db.session.close()
            log(CRITICAL, "Exception", exception, True)
            return jsonify([{"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}], [{}]), 500

        else:
            try:
                query.REMOVED = 1
                db.session.merge(query)
                db.session.commit()
                db.session.close()
                log(INFO, "MachineConsumableRemoved")
                return jsonify([{"status": STATUS_SUCCESS, "code": CODE_SUCCESS}], [{}]), 200

            except Exception as exception:
                db.session.close()
                log(CRITICAL, "Exception", exception, True)
                return jsonify([{"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}], [{}]), 500



@api_app.route("/updateMaterialRequest/<material_key>/<amount>/<id_machine>", methods=["POST"])
@google_token_required
@ke_signature_required
def update_material_request(material_key, amount, id_machine, **kwargs):
    #todo: handle exceptions properly
    try:
        data = flask_request.headers.get("signed_data").split(";")
    except:
        return jsonify({"status": STATUS_FAILED, "code": CODE_NO_RESULTS_FOUND}), 500

        #>data[1] --> material_key
        #>date[2]---> amount
        #>data[3]--->id_machine

    try:
        query = (
            db.session.query(Client)
            .filter(Machine.ID == data[3])
            .filter(Client.ID == Machine.ID_CLIENT)
            .one()
        )

        if material_key == "AL_A356":
            query.AL_A356 = query.AL_A356 - float(amount)
        elif material_key == "AL_C355":
            query.AL_C355 = query.AL_C355 - float(amount)
        elif material_key == "AL_A380":
            query.AL_A380 = query.AL_A380 - float(amount)
        elif material_key == "ZA_ZA12":
            query.ZA_ZA12 = query.ZA_ZA12 - float(amount)
        elif material_key == "ZA_ZA8":
            query.ZA_ZA8 = query.ZA_ZA8 - float(amount)
        elif material_key == "ZA_ZA27":
            query.ZA_ZA27 = query.ZA_ZA27 - float(amount)
        else:
            #Delete date and delete id_client from order
            return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500

        db.session.merge(query)
        db.session.commit()
        db.session.close()

        return jsonify({"status": STATUS_SUCCESS, "code": CODE_SUCCESS}), 200

    except Exception as exception:
        db.session.close()
        log(CRITICAL, "Exception", exception, True)
        return jsonify({"status": STATUS_FAILED, "code": CODE_UNCAUGHT_EXCEPTION}), 500



