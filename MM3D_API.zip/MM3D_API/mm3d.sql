-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2022 at 09:27 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mm3d`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`freaktal_mm3d`@`localhost` PROCEDURE `RemoveUser` (IN `machine_id` INT, IN `uid` VARCHAR(64))  BEGIN
    DELETE FROM `Operators` 
    USING `Operators`, `Users` 
    WHERE `Operators`.`ID_USER` = `Users`.`ID` 
    AND `Users`.`UID` = uid
    AND `Operators`.`ID_MACHINE` = machine_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `arduinos`
--

CREATE TABLE `arduinos` (
  `ID` int(11) NOT NULL,
  `ID_MACHINE` int(11) NOT NULL,
  `ARDUINO_TYPE` int(11) NOT NULL,
  `ARDUINO_UID` varchar(18) NOT NULL,
  `SECRET` varchar(32) NOT NULL,
  `KEY` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `arduinos`
--

INSERT INTO `arduinos` (`ID`, `ID_MACHINE`, `ARDUINO_TYPE`, `ARDUINO_UID`, `SECRET`, `KEY`) VALUES
(1, 1, 0, '6e756e6b776f00100f', 'd81842360fcc332513e1b4962629b50e', '61964aa72a30e38d53b6309779eb85f61971f2876df4f8b79ec7e2dffe90944d'),
(2, 1, 1, '6e756e6b776f00040e', 'f8b73edaf4d29d950231e5c30836ccef', '77d270a77c1d995983c3637310f4a1f9c2cd5c7f7c4f638259f1056d5377f563');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `ID` int(11) NOT NULL,
  `ID_MACHINE` int(11) NOT NULL,
  `ADDRESS` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`ID`, `ID_MACHINE`, `ADDRESS`) VALUES
(1, 1, 'test'),
(2, 2, 'test2');

-- --------------------------------------------------------

--
-- Table structure for table `consumables`
--

CREATE TABLE `consumables` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(64) NOT NULL,
  `TYPE` int(11) NOT NULL,
  `LIFESPAN` int(11) DEFAULT NULL,
  `DENSITY` float DEFAULT NULL,
  `TEMP_CRUCIBLE` int(11) DEFAULT NULL,
  `TEMP_DIES` int(11) DEFAULT NULL,
  `PRICE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `consumables`
--

INSERT INTO `consumables` (`ID`, `NAME`, `TYPE`, `LIFESPAN`, `DENSITY`, `TEMP_CRUCIBLE`, `TEMP_DIES`, `PRICE`) VALUES
(1, 'Crucible', 1, 100, NULL, NULL, NULL, 0),
(2, 'Degassing nozzle', 2, 100, NULL, NULL, NULL, 0),
(3, 'Dies', 3, 1000, NULL, NULL, NULL, 0),
(4, 'Aluminium A356', 4, NULL, 2.685, 680, 280, 0),
(5, 'Zinc', 4, NULL, 7.14, 440, 180, 0),
(7, 'Aluminium', 4, NULL, 2.7, 680, 280, 0),
(8, 'Aluminum A360.0-F', 4, NULL, 2.68, 680, 280, 0),
(9, 'Aluminum A356.2', 4, NULL, 2.67, 680, 280, 0),
(10, 'Aluminum A356.0-T61', 4, NULL, 2.67, 680, 280, 0),
(13, 'Aluminum A380.0-F', 4, NULL, 2.76, 680, 280, 0),
(14, 'Aluminum 384.0-F', 4, NULL, 2.823, 680, 280, 0),
(15, 'Aluminum A383.0-F', 4, NULL, 2.68, 680, 280, 0),
(16, 'Aluminum 383.0-F', 4, NULL, 2.7, 680, 280, 0),
(18, 'Investment Powder', 5, NULL, 2, NULL, NULL, 0),
(19, 'Green sand', 6, NULL, NULL, NULL, NULL, 0),
(20, 'Skimmer', 7, 100, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `consumabletypes`
--

CREATE TABLE `consumabletypes` (
  `ID` int(11) NOT NULL,
  `TYPE` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `consumabletypes`
--

INSERT INTO `consumabletypes` (`ID`, `TYPE`) VALUES
(4, 'Casting material'),
(1, 'Crucible'),
(2, 'Degassing nozzle'),
(3, 'Dies'),
(5, 'Mold material'),
(6, 'Sand material'),
(7, 'Skimmer');

-- --------------------------------------------------------

--
-- Table structure for table `machines`
--

CREATE TABLE `machines` (
  `ID` int(11) NOT NULL,
  `ID_SERIAL` varchar(16) DEFAULT NULL,
  `ID_SECRET` varchar(16) NOT NULL,
  `ID_PI` varchar(16) NOT NULL,
  `MACHINE_TYPE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `machines`
--

INSERT INTO `machines` (`ID`, `ID_SERIAL`, `ID_SECRET`, `ID_PI`, `MACHINE_TYPE`) VALUES
(1, 'cBz2K4DX6817w9m2', 'DmSsrNNemrmUvHZA', '\r\n1000000024e543', 1),
(2, 'Pt4QOknZ9KzTCgpt', '3o9BGlsFXXI4CMs5', '1000000024e1345a', 1),
(106, '6fbhmUMP2xP9J4Ps', '3vHygwUuO6TKzAdo', '00000000001111', 1),
(107, 'WFMTMqVWMSnUDTi8', 'fwlVrCvgfdQpBN5z', '000000000011111', 1),
(111, 'vl5zxELnI7C5FzKb', 'kzkULzf5ky3x2nsh', '121226', 1),
(112, 'loCcDnUKjKyVJKIA', 't2ZryBQJTJTt2rAz', '123123112', 1),
(113, 'x9XupV33IUCJdJUu', 'ubZSNLIk8TL1l8pX', '5656', 1),
(114, 'u86m022iRvhWudQJ', 'jBRQWeCx9dc3BugH', '56567', 1),
(115, '2Iwh6rs251IO8A46', 'NVe0qScjlu0YSB0x', '789789', 1),
(116, 'RXvK59TbpHxCggow', 'jDIldl1DFV0PCO0U', '7897891', 1);

-- --------------------------------------------------------

--
-- Table structure for table `machinetypes`
--

CREATE TABLE `machinetypes` (
  `ID` int(11) NOT NULL,
  `TYPE` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `machinetypes`
--

INSERT INTO `machinetypes` (`ID`, `TYPE`) VALUES
(1, 'M1 Foundry'),
(2, 'M1 Foundry X'),
(3, 'M1 Printer');

-- --------------------------------------------------------

--
-- Table structure for table `operators`
--

CREATE TABLE `operators` (
  `ID` int(11) NOT NULL,
  `ID_USER` int(11) NOT NULL,
  `ID_MACHINE` int(11) NOT NULL,
  `REMOVED` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `operators`
--

INSERT INTO `operators` (`ID`, `ID_USER`, `ID_MACHINE`, `REMOVED`) VALUES
(1, 3, 1, 0),
(2, 3, 2, 0),
(65, 5, 2, 0),
(66, 5, 1, 0),
(67, 5, 107, 0),
(68, 5, 111, 0),
(69, 5, 112, 0),
(70, 5, 113, 0),
(71, 5, 114, 0),
(72, 5, 115, 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ID` int(11) NOT NULL,
  `ID_CLIENT` int(11) NOT NULL,
  `ID_CONSUMABLE` int(11) NOT NULL,
  `ID_SERIAL` varchar(16) NOT NULL,
  `ID_SECRET` varchar(16) NOT NULL,
  `LIFESPAN` int(11) NOT NULL,
  `LIFESPAN_LEFT` float NOT NULL,
  `DATE_ORDER` datetime NOT NULL,
  `DATE_ASSIGNED` datetime DEFAULT NULL,
  `ID_ASSIGNED_MACHINE` int(11) DEFAULT NULL,
  `ASSIGNED_MATERIAL` varchar(64) DEFAULT NULL,
  `ASSIGNED_MODEL` varchar(128) DEFAULT NULL,
  `REMOVED` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `ID_CLIENT`, `ID_CONSUMABLE`, `ID_SERIAL`, `ID_SECRET`, `LIFESPAN`, `LIFESPAN_LEFT`, `DATE_ORDER`, `DATE_ASSIGNED`, `ID_ASSIGNED_MACHINE`, `ASSIGNED_MATERIAL`, `ASSIGNED_MODEL`, `REMOVED`) VALUES
(1, 1, 1, '6xDxJ52VqYoqVbex', 'ZgW7JdHO0iGz0ok0', 100, 54.3, '2020-03-02 00:00:00', '2021-09-28 10:15:50', 1, NULL, NULL, 0),
(2, 1, 2, '0lgp2U7FDvSs8uEM', 'F7DzqB5xl2uA7eM9', 100, 98, '2020-03-25 11:28:32', '2020-03-31 16:03:54', 1, NULL, NULL, 0),
(3, 1, 3, 'PlciGbO1xkoqnUjP', 'SJ8GpbVrKpuc5YrH', 1000, 679, '2020-03-01 00:00:00', '2020-04-01 11:09:40', 2, NULL, NULL, 0),
(4, 1, 4, 'ydWjPsH0RT6M7KQ9', 'PCD6mP9pteN1vecy', 10000, 10000, '2020-03-01 00:00:00', '2020-03-31 16:05:43', 1, NULL, NULL, 0),
(5, 1, 8, 'GWvkIiWx0ocLmFTO', 'q5KNqCwrbDnzgm88', 11111, 11111, '2020-03-16 00:00:00', '2021-09-28 17:15:47', 1, NULL, NULL, 0),
(6, 1, 3, '1cb1DQTF3Vd0kjaq', 'GyoQCsUFoA9QJZDf', 1000, 1000, '2020-03-11 00:00:00', NULL, NULL, NULL, NULL, 0),
(7, 1, 13, 'JqkfrRExQ8FivUe7', 'ZCQ2Ye59xSjMJRd2', 10000, 10000, '2020-03-08 00:00:00', NULL, NULL, NULL, NULL, 0),
(8, 1, 8, 'D0KZ1xL12apVrfJ1', 'HIaUdrwIwFVCWOlp', 10000, 10000, '2020-02-29 00:00:00', NULL, NULL, NULL, NULL, 0),
(9, 1, 10, 'D2Jo7j3P0oPtl5vx', 'FRNblmbZ4sf8ru7z', 10000, 10000, '2020-03-24 00:00:00', NULL, NULL, NULL, NULL, 0),
(10, 1, 5, 'Dc41oLr9DllIuHVh', 'TYChdgtJAu7weJUJ', 10000, 10000, '2020-03-10 00:00:00', '2020-04-01 11:10:01', 1, NULL, NULL, 0),
(11, 1, 18, '8okgJgMmf25wktLC', 'j4w4dnxGdYEx3Z7T', 10000, 10000, '2020-03-11 00:00:00', '2020-04-01 11:10:09', 1, NULL, NULL, 0),
(12, 1, 1, '7c8ji0PPTqEyZXhr', 'xOTF9xa4L85bA2Jq', 100, 100, '2020-03-26 00:00:00', NULL, NULL, NULL, NULL, 0),
(13, 1, 1, '6uTtJyTO3qmd2YFb', 'QmGvDJgGi9q5smNL', 100, 100, '2020-03-26 00:00:00', '2021-09-29 15:33:49', 1, NULL, NULL, 0),
(15, 1, 4, '1uXovv3DT3h2pna9', '00Fq2MvP5Bxx6LwF', 10000, 6686, '2020-03-01 00:00:00', NULL, NULL, NULL, NULL, 0),
(20, 1, 20, 'OZ1HV8lYdxRMetwo', 'Rvfw0hhozyW8jVzT', 100, 100, '2021-09-28 12:15:07', '2021-09-28 17:35:54', 1, NULL, NULL, 0),
(301, 1, 1, 'n5O43bRhVBn2yJ5E', 'HNKK5cIyxJEiEJ8t', 0, 0, '2021-09-30 17:34:28', '2021-09-30 17:34:51', 1, NULL, NULL, 0),
(302, 1, 7, 'YFSvNPQgYNRUhuCG', 'W7g0C91kSAOBz2pk', 0, 0, '2021-09-30 17:35:37', '2021-09-30 17:36:01', 1, NULL, NULL, 0),
(303, 1, 7, 'Jvfnlfxl11ZOk10B', 'nBL953cxdzHFizYJ', 0, 0, '2021-09-30 17:36:42', '2021-09-30 17:37:04', 1, NULL, NULL, 0),
(305, 1, 20, 'eAeLTTlflx9riNrI', 'gPsUANYMT6kCafn9', 0, 0, '2021-09-30 17:38:14', '2021-09-30 17:38:38', 1, NULL, NULL, 0),
(306, 1, 1, 'QK40vYrycQMMcvCp', 'rRnbcHCOfnHnvz4i', 0, 0, '2021-10-01 10:45:30', '2021-10-01 10:45:41', 112, NULL, NULL, 0),
(307, 1, 5, '1UXItaEjnD6PRBOu', 'UwTPKAyokK1RQlNz', 0, 0, '2021-10-01 10:46:28', '2021-10-01 10:46:40', 112, NULL, NULL, 0),
(308, 1, 5, 'wiUvIMuiW25A1ONT', 'Gc3j7YUxhJGwtG6M', 0, 0, '2021-10-01 10:47:06', '2021-10-01 10:47:16', 115, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `UID` varchar(64) NOT NULL,
  `CREATED_AT` datetime NOT NULL DEFAULT current_timestamp(),
  `LAST_LOGIN` datetime NOT NULL DEFAULT current_timestamp(),
  `REMOVED_AT` datetime DEFAULT NULL,
  `REMOVED` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin2;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `UID`, `CREATED_AT`, `LAST_LOGIN`, `REMOVED_AT`, `REMOVED`) VALUES
(3, 'l8kWtOjK04f4J2H0pmj4bBULKC02', '2020-11-27 14:42:04', '2021-09-24 16:49:14', NULL, 0),
(4, 'CXgYJGigskWK15txbeYExm5zm0Z2', '2021-09-23 12:44:11', '2021-09-23 13:00:58', '2021-09-23 13:10:40', 1),
(5, 'CXgYJGigskWK15txbeYExm5zm0Z2', '2021-09-23 13:11:09', '2021-10-04 14:31:36', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arduinos`
--
ALTER TABLE `arduinos`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ARDUINO_UID` (`ARDUINO_UID`),
  ADD UNIQUE KEY `SECRET` (`SECRET`),
  ADD UNIQUE KEY `KEY` (`KEY`),
  ADD KEY `ID_MACHINE` (`ID_MACHINE`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_MACHINE` (`ID_MACHINE`);

--
-- Indexes for table `consumables`
--
ALTER TABLE `consumables`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `NAME` (`NAME`),
  ADD KEY `TYPE` (`TYPE`),
  ADD KEY `TYPE_2` (`TYPE`),
  ADD KEY `NAME_2` (`NAME`);

--
-- Indexes for table `consumabletypes`
--
ALTER TABLE `consumabletypes`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `TYPE` (`TYPE`);

--
-- Indexes for table `machines`
--
ALTER TABLE `machines`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID_PI` (`ID_PI`),
  ADD UNIQUE KEY `ID_SECRET` (`ID_SECRET`),
  ADD UNIQUE KEY `ID_SERIAL_2` (`ID_SERIAL`),
  ADD KEY `MACHINE_TYPE` (`MACHINE_TYPE`),
  ADD KEY `ID_SERIAL` (`ID_SERIAL`),
  ADD KEY `ID_SERIAL_3` (`ID_SERIAL`);

--
-- Indexes for table `machinetypes`
--
ALTER TABLE `machinetypes`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `TYPE` (`TYPE`);

--
-- Indexes for table `operators`
--
ALTER TABLE `operators`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_USER` (`ID_USER`,`ID_MACHINE`),
  ADD KEY `ID_MACHINE` (`ID_MACHINE`),
  ADD KEY `ID_USER_2` (`ID_USER`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID_SERIAL` (`ID_SERIAL`),
  ADD UNIQUE KEY `ID_SECRET` (`ID_SECRET`),
  ADD KEY `TYPE` (`ID_CONSUMABLE`),
  ADD KEY `	ORDER_DATE` (`DATE_ORDER`),
  ADD KEY `ID_ASSIGNED_MACHINE` (`ID_ASSIGNED_MACHINE`),
  ADD KEY `ID_CLIENT` (`ID_CLIENT`),
  ADD KEY `ID_ASSIGNED_MATERIAL` (`ASSIGNED_MATERIAL`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arduinos`
--
ALTER TABLE `arduinos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `consumables`
--
ALTER TABLE `consumables`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `machines`
--
ALTER TABLE `machines`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `machinetypes`
--
ALTER TABLE `machinetypes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `operators`
--
ALTER TABLE `operators`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12346;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `arduinos`
--
ALTER TABLE `arduinos`
  ADD CONSTRAINT `Arduinos_ibfk_1` FOREIGN KEY (`ID_MACHINE`) REFERENCES `machines` (`ID`);

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `Clients_ibfk_1` FOREIGN KEY (`ID_MACHINE`) REFERENCES `machines` (`ID`);

--
-- Constraints for table `consumables`
--
ALTER TABLE `consumables`
  ADD CONSTRAINT `Consumables_ibfk_1` FOREIGN KEY (`TYPE`) REFERENCES `consumabletypes` (`ID`);

--
-- Constraints for table `machines`
--
ALTER TABLE `machines`
  ADD CONSTRAINT `Machines_ibfk_1` FOREIGN KEY (`MACHINE_TYPE`) REFERENCES `machinetypes` (`ID`);

--
-- Constraints for table `operators`
--
ALTER TABLE `operators`
  ADD CONSTRAINT `Operators_ibfk_1` FOREIGN KEY (`ID_USER`) REFERENCES `users` (`ID`),
  ADD CONSTRAINT `Operators_ibfk_2` FOREIGN KEY (`ID_MACHINE`) REFERENCES `machines` (`ID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `Orders_ibfk_2` FOREIGN KEY (`ID_CONSUMABLE`) REFERENCES `consumables` (`ID`),
  ADD CONSTRAINT `Orders_ibfk_3` FOREIGN KEY (`ID_ASSIGNED_MACHINE`) REFERENCES `machines` (`ID`),
  ADD CONSTRAINT `Orders_ibfk_4` FOREIGN KEY (`ID_CLIENT`) REFERENCES `clients` (`ID`),
  ADD CONSTRAINT `Orders_ibfk_5` FOREIGN KEY (`ASSIGNED_MATERIAL`) REFERENCES `consumables` (`NAME`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
